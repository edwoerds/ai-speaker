  #include "bt_manager.h"
  #include "event_bus.h"
  #include "logger.h"
  #include "module.h"

  #include <bluetooth/bluetooth.h>
  #include <bluetooth/rfcomm.h>
  #include <errno.h>
  #include <pthread.h>
  #include <signal.h>
  #include <stdio.h>
  #include <stdlib.h>
  #include <string.h>
  #include <sys/socket.h>
  #include <unistd.h>
    #include <sys/time.h>
    #include<systemd/sd-bus.h>
  #define BT_ACCEPT_TIMEOUT_S  2
  #define BT_READ_TIMEOUT_S    5
  static struct {
    int srv_fd;
    int cli_fd;
    sd_bus *bus;
    pthread_t thread;
    volatile bool running;
    volatile bool connected;
  } s_bt={.cli_fd=-1,.srv_fd=-1};

  /*
 * BlueZ D-Bus 属性设置
 *
 * 通过 org.freedesktop.DBus.Properties.Set 接口设置 BlueZ Adapter1 属性
 *
 * D-Bus 调用结构：
 *   服务名:  org.bluez
 *   对象路径: /org/bluez/hci0
 *   接口:    org.freedesktop.DBus.Properties
 *   方法:    Set(interface, property, variant_value)
 *
 * 为什么不用 system("hciconfig...")？
 *   1. system() fork 子进程，慢且不可靠
 *   2. hciconfig 是 BlueZ 废弃工具
 *   3. A2DP 必须用 D-Bus，提前引入
 */

 static int adapter_set_bool(const char *prop,int value){
  sd_bus_error error = SD_BUS_ERROR_NULL;
  sd_bus_message *msg=NULL;
  int r;
  r=sd_bus_message_new_method_call(s_bt.bus, &msg,"org.bluez", "/org/bluez/hci0",
                        "org.freedesktop.DBus.Properties", "Set");
  if(r<0) return r;
  r=sd_bus_message_append(msg,"ss","org.bluez.Adapter1",prop);

  if(r<0) goto finish;
  r=sd_bus_message_open_container(msg, 'v', "b");

  if(r<0) goto finish;
  r=sd_bus_message_append(msg, "b", value);

  if(r<0) goto finish;
  r=sd_bus_message_close_container(msg);

  if(r<0) goto finish;
  r=sd_bus_call(s_bt.bus, msg, 0, &error,NULL);

  if(r<0){
    LOG_ERROR("BT D-Bus Set(%s) failed: %s", prop, error.message);
  }
  finish:
    sd_bus_error_free(&error);
    sd_bus_message_unref(msg);
    return r;
 }

static int adapter_set_string(const char *prop,const char *value){
  sd_bus_error error=SD_BUS_ERROR_NULL;
  sd_bus_message *msg=NULL;
  int r;
  r=sd_bus_message_new_method_call(s_bt.bus, &msg,"org.bluez", "/org/bluez/hci0",
                        "org.freedesktop.DBus.Properties", "Set");
  if(r<0) return r;
  r=sd_bus_message_append(msg, "ss", "org.bluez.Adapter1", prop);

  if(r<0) goto finish;
  r=sd_bus_message_open_container(msg, 'v', "s");

  if(r<0) goto finish;
  r=sd_bus_message_append(msg, "s", value);

  if(r<0) goto finish;
  r=sd_bus_message_close_container(msg);

  if(r<0) goto finish;
  r=sd_bus_call(s_bt.bus, msg, 0, &error,NULL);

  if(r<0){
    LOG_ERROR("BT D-Bus Set(%s) failed: %s", prop, error.message);
  }
  finish:
    sd_bus_error_free(&error);
    sd_bus_message_unref(msg);
    return r;
}

  static void *bt_thread(void *arg){
    const bt_manager_config_t *cfg=(const bt_manager_config_t*)arg;   

    struct timeval accept_tv = { .tv_sec = BT_ACCEPT_TIMEOUT_S, .tv_usec = 0 };
  setsockopt(s_bt.srv_fd, SOL_SOCKET, SO_RCVTIMEO, &accept_tv, sizeof(accept_tv));

    while(s_bt.running){
      struct sockaddr_rc client_addr;
      socklen_t addrlen=sizeof(client_addr);
      s_bt.cli_fd=accept(s_bt.srv_fd,(struct sockaddr*)&client_addr,&addrlen);
      if(s_bt.cli_fd<0){
        if(errno == EAGAIN || errno == EWOULDBLOCK) continue; /* 超时，正常轮询 */
        if(s_bt.running)
        LOG_ERROR("BT accept failed: %s", strerror(errno));
        continue;
        }
        /* re;ad 超时5s 无数据视为断连 */
        struct timeval read_tv = { .tv_sec = BT_READ_TIMEOUT_S, .tv_usec = 0 };
        setsockopt(s_bt.cli_fd, SOL_SOCKET, SO_RCVTIMEO, &read_tv, sizeof(read_tv));

        char peer[32]={0};
        ba2str(&client_addr.rc_bdaddr,peer);
        LOG_INFO("BT connected: %s", peer);
        s_bt.connected=true;
        event_publish_simple(EV_BT_DEVICE_CONN);
        char buf[1024];
        while(s_bt.running){
          ssize_t n=read(s_bt.cli_fd,buf,sizeof(buf)-1);
          if(n<=0){
            if(errno == EAGAIN || errno == EWOULDBLOCK) continue;
            break;
          }
          buf[n]='\0';
          LOG_INFO("BT recv (%zd): %s", n, buf);
          event_publish_string(EV_BT_DATA_RECEIVED,buf);
        }
        LOG_INFO("BT disconnected: %s",peer);
        close(s_bt.cli_fd);
        s_bt.cli_fd=-1;
        s_bt.connected=false;
        event_publish_simple(EV_BT_DEVICE_DISCONN);

        if(cfg->auto_reconnect){
          LOG_INFO("BT auto-reconnect: waiting...");
        }
      }
    return NULL;
  }
  //接口实现
  err_t bt_manager_init(const bt_manager_config_t *cfg){
    if(!cfg) return ERR_INVAL;
          // * 三条命令的作用：
        //1. hciconfig hci0 up          = 打开蓝牙适配器（相当于手机上点"蓝牙开关"）
         // 2. hciconfig hci0 name "xxx"  = 给蓝牙取个名字，别人搜到显示这个
        //  3. hciconfig hci0 piscan      = pi(可发现) + scan(可被扫描)
                                          //别人能搜到你，也能连你
    //char cmd[256];      
    //snprintf(cmd,sizeof(cmd),"hciconfig hci0 up 2>/dev/null");       
    //system(cmd);        
    //snprintf(cmd, sizeof(cmd),"hciconfig hci0 name \"%s\" 2>/dev/null", cfg->device_name);
    //system(cmd);
    //snprintf(cmd, sizeof(cmd), "hciconfig hci0 piscan 2>/dev/null");
    //system(cmd);


    //改写
    //打开 BlueZ D-Bus 连接
    int r=sd_bus_open_system(&s_bt.bus);
    if(r<0){
      LOG_ERROR("BT: failed to open system bus: %s", strerror(-r));
      return ERR_NODEV;
    }
    //1. 打开蓝牙适配器（Powered = true）
    int on=1;
    r= adapter_set_bool("Powered", on);
    if(r<0){
         LOG_ERROR("BT: failed to power on adapter");
         sd_bus_unref(s_bt.bus);
         s_bt.bus=NULL;
         return ERR_NODEV;
    }

    //2. 设置设备名称（Alias）
    r=adapter_set_string("Alias", cfg->device_name);
    if(r<0){
      LOG_WARN("BT: failed to set alias (ignored)");
    }

    //3. 设为可发现（Discoverable = true）
    r=adapter_set_bool("Discoverable", on);
    if(r<0){
       LOG_WARN("BT: failed to set discoverable (ignored)");
    }


    s_bt.srv_fd=socket(AF_BLUETOOTH,SOCK_STREAM,BTPROTO_RFCOMM);
    if(s_bt.srv_fd<0) {
      LOG_ERROR("BT socket failed: %s", strerror(errno));
      sd_bus_unref(s_bt.bus);
      s_bt.bus=NULL;
          return ERR_NODEV;
    }
    struct sockaddr_rc addr={0};
    addr.rc_family=AF_BLUETOOTH;
    addr.rc_channel=1;
    bacpy(&addr.rc_bdaddr,BDADDR_ANY);
    //绑定
    if(bind(s_bt.srv_fd,(struct sockaddr *)&addr,sizeof(addr))<0){
      LOG_ERROR("BT bind failed: %s", strerror(errno));
      close(s_bt.srv_fd);
      sd_bus_unref(s_bt.bus);
      s_bt.bus=NULL;
      return ERR_NODEV;
    }
    listen(s_bt.srv_fd, 1);
    s_bt.running=true;
    pthread_create(&s_bt.thread, NULL, bt_thread, (void*)cfg);
    LOG_INFO("Bluetooth initialized (%s)", cfg->device_name);
    return ERR_OK;
  }

  void bt_manager_deinit(void){
       //关闭顺序极其重要，错了可能死锁或崩溃
          //正确顺序：
          //1. 设 running=false（告诉线程：该停了）
          //2. 关闭 socket（踢醒阻塞在 accept/read 的线程）
          //3. pthread_join（等线程自己退出，而不是强行杀掉它）
          //4. 关蓝牙
          
      s_bt.running=false;

    if(s_bt.bus){
      int off=0;
      adapter_set_bool("Powered", off);
      sd_bus_unref(s_bt.bus);
      s_bt.bus=NULL;
    }

      if (s_bt.cli_fd >= 0) {
        shutdown(s_bt.cli_fd, SHUT_RDWR);
        close(s_bt.cli_fd);
        s_bt.cli_fd = -1;
      }
      if(s_bt.srv_fd>=0) {
        shutdown(s_bt.srv_fd,SHUT_RDWR);
        close(s_bt.srv_fd);
        s_bt.srv_fd=-1;
      }
      
      pthread_join(s_bt.thread, NULL);
      LOG_INFO("Bluetooth deinitialized");
  }

  void bt_manager_shutdown(void){
      s_bt.running=false;
  }

  bool bt_manager_is_connected(void){
      return s_bt.connected;
  } 

  static err_t bt_init(void){
    static bt_manager_config_t s_cfg={
            .device_name ="AI-Speaker",
            .discoverable_timeout=300,
            .auto_reconnect=true,
    };
    //return bt_manager_init(&s_cfg);
    err_t err = bt_manager_init(&s_cfg);
    if (IS_ERR(err)) {
      LOG_WARN("BT hardware unavailable, continuing without Bluetooth");
      return ERR_OK;  /* 非致命——没蓝牙也能跑 */
    }
     return ERR_OK;
  }

  static void bt_deinit(void){
    bt_manager_deinit();
  }

  static void bt_shutdown(void){
    bt_manager_shutdown();
}
MODULE_DEFINE(bt, bt_init, bt_deinit, bt_shutdown, MODULE_PRIO_SERVICE);