#include "bt_a2dp.h"
#include "audio_player.h"
#include "event_bus.h"
#include "logger.h"
#include "module.h"

#include <pthread.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <systemd/sd-bus.h>
#include <unistd.h>

/* ducking 衰减系数（bt_a2dp.h 不暴露实现细节，定义在这里） */
#define DUCKING_FACTOR 0.3f

/*
 * A2DP Sink 实现
 *
 === 架构 ===
 *  init:
 *    1. 注册 BlueZ A2DP Sink Profile（D-Bus MediaEndpoint1）
 *    2. 启动独立线程: 接收 PCM 流 -> 入环形缓冲
 *    3. 启动独立线程: 从环形缓冲取数据 -> audio_player.stream_write()
 *
 *  init 失败不回滚 D-Bus，因为 audio_player 初始化在 voice_agent 中先于我们
 *
 === D-Bus 回调流程 ===
 *  SelectConfiguration  → 确认配置
 *  SetConfiguration     → 拿到 transport 对象路径 → 启动 transport 线程读 fd
 *  ClearConfiguration   → 停止 transport 线程
 *  Release              → 端点释放
 *
 === 线程 ===
  *  transport_thread — 读 BlueZ transport fd → 入环形缓冲
 *  play_thread      — 读环形缓冲 → ducking 衰减 → audio_player.stream_write()
 */

/* ==================================================================
 * PCM 环形缓冲
 * ================================================================ */

 #define A2DP_CHANNELS      2
#define A2DP_BITS          16
#define A2DP_FRAME_BYTES   (A2DP_CHANNELS * A2DP_BITS / 8)  /* = 4 */
#define A2DP_SAMPLE_RATE   44100
#define RINGBUF_DEFAULT_FRAMES  256
#define IDLE_SILENCE_FRAMES     4096


typedef struct {
    int16_t      *buf;
    size_t        capacity;
    volatile size_t read_pos;
    volatile size_t write_pos;
    volatile size_t count;
} pcm_ringbuf_t;


static void ringbuf_init(pcm_ringbuf_t *rb, size_t frames)
{
    rb->buf = calloc(frames, A2DP_FRAME_BYTES);
    rb->capacity = frames;
    rb->read_pos = 0;
    rb->write_pos = 0;
    rb->count = 0;
}

static void ringbuf_destroy(pcm_ringbuf_t *rb)
{
    free(rb->buf);
    rb->buf = NULL;
    rb->capacity = 0;
}


static void ringbuf_put(pcm_ringbuf_t *rb, const int16_t *frames, size_t n)
{
    for (size_t i = 0; i < n; i++) {
        rb->buf[rb->write_pos * A2DP_CHANNELS + 0] = frames[i * A2DP_CHANNELS + 0];
        rb->buf[rb->write_pos * A2DP_CHANNELS + 1] = frames[i * A2DP_CHANNELS + 1];
        rb->write_pos = (rb->write_pos + 1) % rb->capacity;
        if (rb->count < rb->capacity) {
            rb->count++;
        } else {
            rb->read_pos = (rb->read_pos + 1) % rb->capacity;
        }
    }
}


static size_t ringbuf_get(pcm_ringbuf_t *rb, int16_t *frames, size_t n)
{
    size_t read = 0;
    while (read < n && rb->count > 0) {
        frames[read * A2DP_CHANNELS + 0] = rb->buf[rb->read_pos * A2DP_CHANNELS + 0];
        frames[read * A2DP_CHANNELS + 1] = rb->buf[rb->read_pos * A2DP_CHANNELS + 1];
        rb->read_pos = (rb->read_pos + 1) % rb->capacity;
        rb->count--;
        read++;
    }
    return read;
}

/* ==================================================================
 * 全局状态
 * ================================================================ */


static struct {
      bt_a2dp_config_t cfg;// 配置：device、ringbuf_frames
      pcm_ringbuf_t    ringbuf;// PCM 环形缓冲

      /* 线程 */
      pthread_t       play_thread;        // ALSA 播放线程
      pthread_t       transport_thread;   // 读 BlueZ fd 的线程（独立线程！）
      volatile bool   running;           // 模块正在运行？

      /* ducking */
      volatile bool   ducking;              // 需要衰减音量？

      /* D-Bus */
      sd_bus         *bus;               // D-Bus 系统总线连接
      sd_bus_slot    *slot;              // D-Bus vtable 注册槽位
      char           *endpoint_path;     // 我们注册的对象路径
      int             transport_fd;      // BlueZ 给的 PCM 数据 fd
      volatile bool   transport_active;  // 有活跃传输吗？

      bool            music_start_published;// 已发了 MUSIC_START 没？
  } s_a2dp = {0};


  /* ==================================================================
 * ALSA 播放线程
 * ================================================================ */

 static inline void apply_ducking(int16_t *frames,size_t n){
    if(!s_a2dp.ducking) return;
    for(size_t i=0;i<n*A2DP_CHANNELS;i++){
        frames[i]=(int16_t)(frames[i]*DUCKING_FACTOR);
    }
 }



 /*
 * 播放线程：从环形缓冲取 PCM 数据 → ducking → audio_player 播放
 *
 * 这是架构中"独立线程"的第二部分。
 * 第一部分是 transport_thread（从 BlueZ 读数据入缓冲）。
 */

static void *playback_thread(void *arg)
{
    (void)arg;

    size_t buf_frames = s_a2dp.ringbuf.capacity;
    int16_t *buf = malloc(buf_frames * A2DP_FRAME_BYTES);
    if (!buf) {
        LOG_ERROR("A2DP: play thread OOM");
        return NULL;
    }

    /* 静音帧（缓冲空时防 underrun） */
    int16_t *silence = calloc(IDLE_SILENCE_FRAMES, A2DP_FRAME_BYTES);
    if (!silence) {
        free(buf);
        return NULL;
    }

    LOG_INFO("A2DP: playback thread started");
    while(s_a2dp.running){
        size_t frames_read=ringbuf_get(&s_a2dp.ringbuf,buf,buf_frames);

        if(frames_read>0){
            apply_ducking(buf,frames_read);
                        /*
             * 调 audio_player 的流式接口播放。
             * 这就是架构说的 -> audio_player.play_pcm()
             */
            err_t err=audio_player_stream_write(buf,frames_read);
            if(IS_ERR(err)){
                LOG_WARN("A2DP: stream_write error,retrying...");
                usleep(1000);
            }
        }else{
            if(s_a2dp.transport_active){
                //传输中但缓冲空了 → 送静音防 underrun
                err_t err=audio_player_stream_write(silence,IDLE_SILENCE_FRAMES);
                if(IS_ERR(err)){
                    usleep(1000);
                }
            }else{
                //没有活跃传输 → 休眠省 CPU
                usleep(10000);
            }
        }
    }
    free(silence);
    free(buf);
    LOG_INFO("A2DP: playback thread exited");
    return NULL;
}


/* ==================================================================
 * Transport 线程
 * ================================================================ */

/*
 * Transport 线程：从 BlueZ 给的 fd 读 PCM 数据 → 写入环形缓冲
 *
 * 这就是架构中说的"独立线程: 接收 PCM 流 -> 入环形缓冲"
 * 被 D-Bus 的 SetConfiguration 回调启动。
 */
static void *transport_thread(void *arg)
{
    (void)arg;
    int fd = s_a2dp.transport_fd;
    if (fd < 0) return NULL;

    /* 临时缓冲区：读 MTU 大小的数据 */
    size_t read_buf_size = 2048;  /* A2DP 典型 MTU */
    uint8_t *read_buf = malloc(read_buf_size);
    if (!read_buf) {
        LOG_ERROR("A2DP: transport thread OOM");
        return NULL;
    }

    LOG_INFO("A2DP: transport thread started (fd=%d)", fd);

     while(s_a2dp.running){
        ssize_t n =read(fd,read_buf,read_buf_size);
        if(n<0){
            if(errno==EAGAIN||errno==EINTR){
                usleep(1000);
                continue;
            }
            /* EOF 或错误 → 传输结束 */
            break;
        }
        //写入环形缓冲
        size_t frames=(size_t)n/A2DP_FRAME_BYTES;
        ringbuf_put(&s_a2dp.ringbuf,(const int16_t *)read_buf,frames);
     }

     free(read_buf);

     //传输结束 → 发布事件
     s_a2dp.transport_active=false;
     if(s_a2dp.music_start_published){
        event_publish_simple(EV_AUDIO_MUSIC_STOP);
        s_a2dp.music_start_published=false;
     }

     if(s_a2dp.transport_fd>=0){
        close(s_a2dp.transport_fd);
        s_a2dp.transport_fd =-1;
     }

     LOG_INFO("A2DP: transport thread exited");
     return NULL;
 }
 

 /* ==================================================================
 * D-Bus A2DP 端点实现
 * ================================================================ */
#define A2DP_ENDPOINT_PATH  "/org/bluez/speaker/a2dp_sink"
#define A2DP_SINK_UUID      "0000110B-0000-1000-8000-00805F9B34FB"


static const uint8_t sbc_capabilities[] = {
    0x00,       /* SBC */
    0xFF,       /* 采样率 */
    0xFF,       /* 声道 */
    0x02, 0x11, /* 块长度、子带、分配方法 */
    0x02, 0x11, /* 最小时钟池、最大时钟池 */
};


//SelectConfiguration — BlueZ 问我们支持什么配置
static int select_config_cb(sd_bus_message *msg,void *user_data,sd_bus_error *ret_error){
    (void) user_data;
    (void)ret_error;
    const void *config;
    size_t len;
    int r;

    r=sd_bus_message_read_array(msg,'y',&config,&len);
    if(r<0) return r;

    LOG_DEBUG("A2DP: SelectConfiguration (len=%zu)", len);

    r=sd_bus_reply_method_return(msg,"ay",sbc_capabilities,sizeof(sbc_capabilities));

    return r;
}


static int set_config_cb(sd_bus_message *msg,void *user_data,sd_bus_error *ret_error){
    (void)user_data;
    (void)ret_error;
    const char *transport_path;
    int r;

    r=sd_bus_message_read(msg,"o",&transport_path);
    if(r<0) return r;
    r=sd_bus_message_skip(msg, "a{sv}");
    if(r<0) return r;   

    LOG_INFO("A2DP: transport ready: %s", transport_path);

    //获取传输 fd
    sd_bus_error err=SD_BUS_ERROR_NULL;
    sd_bus_message *reply=NULL;
    sd_bus_message *acquire_msg=NULL;
    int fd =-1;
    uint16_t mtu=0;

    r=sd_bus_message_new_method_call(
        s_a2dp.bus,&acquire_msg,
        "org.bluez",transport_path,
        "org.bluez.MediaTransport1","Acquire"
    );

    if(r<0) goto done;

    r=sd_bus_call(s_a2dp.bus,acquire_msg,5000,&err,&reply);
    if(r<0){
        LOG_ERROR("A2DP: Acquire failed: %s", err.message);
        goto done;
    }

    r=sd_bus_message_read(reply, "hq", &fd);
    if(r<0) goto done;

    s_a2dp.transport_fd=dup(fd);
    if(s_a2dp.transport_fd<0){
        LOG_ERROR("A2DP: dup fd failed: %s", strerror(errno));
        r=-1;
        goto done;
    }

    //启动 audio_player 流式模式
    r=audio_player_stream_start(A2DP_SAMPLE_RATE, A2DP_CHANNELS);
    if(IS_ERR((err_t)r)){
        LOG_WARN("A2DP: stream_start failed, continuing...");
    }

    //发布 MUSIC_START
    if(!s_a2dp.music_start_published){
        event_publish_simple(EV_AUDIO_MUSIC_START);
        s_a2dp.music_start_published=true;
    }

    /*
     * 启动独立线程读取 PCM — 满足架构：
     *   "启动独立线程: 接收 PCM 流 -> 入环形缓冲"
     */
    s_a2dp.transport_active=true;
    pthread_create(&s_a2dp.transport_thread, NULL, transport_thread, NULL);
    pthread_detach(s_a2dp.transport_thread);

    LOG_INFO("A2DP: transport acquired (fd=%d, MTU=%u)", fd, mtu);

done:
    sd_bus_error_free(&err);
    sd_bus_message_unref(reply);
    sd_bus_message_unref(acquire_msg);
    return r;
}

//ClearConfiguration — 传输结束
static int clear_config_cb(sd_bus_message *msg,void *user_data,sd_bus_error *ret_error){
    (void)user_data;
    (void)ret_error;
    const char *transport_path;
    int r;

    r=sd_bus_message_read(msg,"o",&transport_path);
    if(r<0) return r;

    LOG_INFO("A2DP: ClearConfiguration: %s", transport_path);

    //停 transport 线程
    s_a2dp.transport_active= false;
    if(s_a2dp.transport_fd>=0){
        close(s_a2dp.transport_fd);
        s_a2dp.transport_fd=-1;
    }

    //停 audio_player 流式
    audio_player_stream_stop();

    if(s_a2dp.music_start_published){
        event_publish_simple(EV_AUDIO_MUSIC_STOP);
        s_a2dp.music_start_published=false;
    }
    
    return sd_bus_reply_method_return(msg, "");
}


//端点释放
static int release_cb(sd_bus_message *msg,void *user_data,sd_bus_error *ret_error){
    (void)user_data;
    (void)ret_error;
    LOG_INFO("A2DP: endpoint released");
    return sd_bus_reply_method_return(msg, "");
}

//MediaEndpoint1 vtable
//   一行注册一个 D-Bus 方法：
  // - "SelectConfiguration" — D-Bus 方法名
  // - "ay" — 输入参数类型（array of bytes）
 /////- "ay" — 输出参数类型（array of bytes）
 // - select_config_cb — 对应的 C 函数
  // - 0 — flags
static const sd_bus_vtable endpoint_vtable[]={
    SD_BUS_VTABLE_START(0),
    SD_BUS_METHOD("SelectConfiguration", "ay", "ay",
                  select_config_cb, 0),
    SD_BUS_METHOD("SetConfiguration", "oa{sv}", "",//SetConfiguration 的输入是 "oa{sv}"（object path + dict），输出是 ""（void）
                  set_config_cb, 0),
    SD_BUS_METHOD("SelectProperties", "a{sv}", "a{sv}",
                  NULL, 0),
    SD_BUS_METHOD("ClearConfiguration", "o", "",
                  clear_config_cb, 0),
    SD_BUS_METHOD("Release", "", "",
                  release_cb, 0),
    SD_BUS_VTABLE_END
};

//注册 A2DP Sink 端点到 BlueZ
static int register_a2dp_endpoint(void){
    int r;

    r=sd_bus_add_object_vtable(s_a2dp.bus,&s_a2dp.slot,
        A2DP_ENDPOINT_PATH,
        "org.bluez.MediaEndpoint1",
        endpoint_vtable,
        NULL);
    if(r<0){
        LOG_ERROR("A2DP: add_object_vtable failed: %s", strerror(-r));
        return r;
    }

    sd_bus_error err=SD_BUS_ERROR_NULL;
    sd_bus_message *msg=NULL;

    r=sd_bus_message_new_method_call(
            s_a2dp.bus, &msg,
            "org.bluez", "/org/bluez",
            "org.bluez.Media1", "RegisterEndpoint");
    if(r<0) goto finish;

    //参数: endpoint 对象路径
    r=sd_bus_message_append(msg,"o", A2DP_ENDPOINT_PATH);
    if(r<0) goto finish;

    //参数: properties dict (a{sv})
    r=sd_bus_message_open_container(msg, 'a', "{sv}");
    if(r<0) goto finish;   
    
    //UUID
    r = sd_bus_message_open_container(msg, 'e', "sv");
    if (r < 0) goto finish;
    r = sd_bus_message_append(msg, "s", "UUID");
    if (r < 0) goto finish;
    r = sd_bus_message_open_container(msg, 'v', "s");
    if (r < 0) goto finish;
    r = sd_bus_message_append(msg, "s", A2DP_SINK_UUID);
    if (r < 0) goto finish;
    r = sd_bus_message_close_container(msg);
    if (r < 0) goto finish;
    r = sd_bus_message_close_container(msg);
    if (r < 0) goto finish;

    //Codec
    r = sd_bus_message_open_container(msg, 'e', "sv");
    if (r < 0) goto finish;
    r = sd_bus_message_append(msg, "s", "Codec");
    if (r < 0) goto finish;
    r = sd_bus_message_open_container(msg, 'v', "y");
    if (r < 0) goto finish;
    r = sd_bus_message_append(msg, "y", (uint8_t)0x00);
    if (r < 0) goto finish;
    r = sd_bus_message_close_container(msg);
    if (r < 0) goto finish;
    r = sd_bus_message_close_container(msg);
    if (r < 0) goto finish;

    //Capabilities
    r = sd_bus_message_open_container(msg, 'e', "sv");
    if (r < 0) goto finish;
    r = sd_bus_message_append(msg, "s", "Capabilities");
    if (r < 0) goto finish;
    r = sd_bus_message_open_container(msg, 'v', "ay");
    if (r < 0) goto finish;
    r = sd_bus_message_append_array(msg, 'y',
                                     sbc_capabilities,
                                     sizeof(sbc_capabilities));
    if (r < 0) goto finish;
    r = sd_bus_message_close_container(msg);
    if (r < 0) goto finish;
    r = sd_bus_message_close_container(msg);
    if (r < 0) goto finish;

    r = sd_bus_message_close_container(msg);
    if (r < 0) goto finish;

    r=sd_bus_call(s_a2dp.bus,msg,5000,&err, NULL);
    if(r<0){
        LOG_ERROR("A2DP: RegisterEndpoint failed: %s", err.message);
    }else{
        LOG_INFO("A2DP: endpoint registered");
    }

finish:
    sd_bus_error_free(&err);
    sd_bus_message_unref(msg);
    return r;
}

//公开API

err_t bt_a2dp_init(const bt_a2dp_config_t *cfg){
    if(s_a2dp.running) return ERR_OK;
    if(cfg) s_a2dp.cfg=*cfg;
    if(!s_a2dp.cfg.device) s_a2dp.cfg.device="default";
    if(s_a2dp.cfg.ringbuf_frames<=0)
        s_a2dp.cfg.ringbuf_frames=RINGBUF_DEFAULT_FRAMES;

    //初始化环形缓冲
    ringbuf_init(&s_a2dp.ringbuf, (size_t)s_a2dp.cfg.ringbuf_frames);
    if(!s_a2dp.ringbuf.buf){
        LOG_ERROR("A2DP: ringbuf init failed");
        return ERR_NOMEM;
    }

    //打开d-bus
    int r=sd_bus_open_system(&s_a2dp.bus);
    if(r<0){
        LOG_ERROR("A2DP: sd_bus_open_system failed: %s", strerror(-r));
        ringbuf_destroy(&s_a2dp.ringbuf);
        return ERR_NODEV;
    }
    //启动 ALSA 播放线程
    s_a2dp.running=true;
    pthread_create(&s_a2dp.play_thread, NULL, playback_thread, NULL);
    //注册 A2DP endpoint
    r=register_a2dp_endpoint();
    if(r<0){
        LOG_WARN("A2DP: endpoint registration failed, A2DP unavailable");
    }
    LOG_INFO("A2DP initialized (device=%s, ringbuf=%d)",
             s_a2dp.cfg.device, s_a2dp.cfg.ringbuf_frames);
    return ERR_OK;
}

void bt_a2dp_set_ducking(bool duck)
{
    s_a2dp.ducking = duck;
    LOG_DEBUG("A2DP ducking: %s", duck ? "ON (*0.3)" : "OFF (*1.0)");
}

void bt_a2dp_shutdown(void)
{
    s_a2dp.running = false;
    s_a2dp.transport_active = false;
    if (s_a2dp.transport_fd >= 0) {
        close(s_a2dp.transport_fd);
        s_a2dp.transport_fd = -1;
    }
    audio_player_stream_stop();
    LOG_INFO("A2DP: shutdown requested");
}

void bt_a2dp_deinit(void){
    bt_a2dp_shutdown();

    if(s_a2dp.play_thread){
        pthread_join(s_a2dp.play_thread,NULL);
        s_a2dp.play_thread=0;
    }

    //注销 D-Bus endpoint
    if(s_a2dp.bus){
        if(s_a2dp.endpoint_path){
            sd_bus_error err=SD_BUS_ERROR_NULL;
            sd_bus_message *msg=NULL;
            int r;
            r=sd_bus_message_new_method_call(
                s_a2dp.bus, &msg,
                "org.bluez", "/org/bluez",
                "org.bluez.Media1", "UnregisterEndpoint"
            );
            if(r==0){
                sd_bus_message_append(msg,"o",s_a2dp.endpoint_path);
                sd_bus_call(s_a2dp.bus, msg, 5000, &err, NULL);
            }
            sd_bus_error_free(&err);
            sd_bus_message_unref(msg);
        }
        sd_bus_unref(s_a2dp.bus);
        s_a2dp.bus=NULL;
    }
    free(s_a2dp.endpoint_path);
    s_a2dp.endpoint_path=NULL;
    ringbuf_destroy(&s_a2dp.ringbuf);

    if(s_a2dp.music_start_published){
        event_publish_simple(EV_AUDIO_MUSIC_STOP);
        s_a2dp.music_start_published=false;
    }
    s_a2dp.ducking=false;
    s_a2dp.transport_active=false;
    s_a2dp.transport_fd=-1;
    LOG_INFO("A2DP deinitialized");
}

/* 生命周期由 audio_pipeline 管理，无需 MODULE_DEFINE */