#include "voice_agent.h"
  #include "ai_client.h"
#include "audio_pipeline.h"
  #include "config.h"
  #include "event_bus.h"
  #include "logger.h"
  #include "module.h"
  #include "state_machine.h"
  #include "thread_pool.h"

  #include <stdio.h>
  #include <stdlib.h>
  #include <string.h>
  #include <unistd.h>
  #include <time.h>
  #include <pthread.h>
/*
 * 语音助手 — 四层架构的应用层
 *
 * 职责：
 *  状态表驱动事件路由、AI 请求调度、TTS+播放编排
 *  只通过 event_bus 通信，不直调服务层模块
 *  阻塞操作（HTTP）通过 thread_pool 异步执行
 */
   //全局状态

  static struct {
      bool          inited;//inited — 防重复 init / deinit
      subscription_t *sub_bt_data;
      subscription_t *sub_ai_ready;
      subscription_t *sub_ai_error;
      subscription_t *sub_play_done;
      subscription_t *sub_audio_error;
      subscription_t *sub_music_start;
      subscription_t *sub_music_stop;
      subscription_t *sub_shutdown;
      subscription_t *sub_disconn;

      /* 触发当前状态转移的事件（action 通过它访问事件数据） */
      const event_t *current_ev;

      /* 超时检测：进入当前状态的时间戳 + 检查线程 */
      int64_t         state_entry_time;
      pthread_t       timeout_thread;
  } s_va = {0};\
   static void on_event(const event_t *ev, void *user_data);
   static void ai_stream_cb(const char *chunk, int is_done, void *user_data);


   //线程池任务：AI 请求
   //这是在线程池 worker 里运行的
   //arg 是从 do_ai_request 里传过来的 strdup 的文本拷贝
   //判空是防御性编程——万一
  //thread_pool_submit 内部出问题传了个 NULL
   static void ai_request_task(void *arg){
     char *text=(char *)arg;
     if(!text) return;
     //1. 追加用户消息到对话历史
    ai_conv_append("user",text);
    //2.构建 JSON payload 
    char *payload=ai_conv_build_payload();
    if(!payload){
        LOG_ERROR("VA: failed to build payload");
        event_publish_simple(EV_AI_ERROR);
        free(text);
        return;
    }
    //3. 发起流式 HTTP 请求（SSE 回调发布流块事件）
    err_t err=ai_client_chat(payload,ai_stream_cb, NULL);
    free(payload);
    if(IS_ERR(err)){
        LOG_ERROR("VA: AI chat request failed");
        event_publish_simple(EV_AI_ERROR);
    }
    free(text);
   }

   // SSE 流式回调
   static void ai_stream_cb(const char *chunk, int is_done, void *user_data){
       (void)user_data;
       if(chunk&&!is_done){
        event_publish_string(EV_AI_STREAM_CHUNK, chunk);
       }
        if(is_done){
            if(chunk&&chunk[0]!='\0'){
                event_publish_string(EV_AI_RESP_READY, chunk);
            }else{
                event_publish_simple(EV_AI_ERROR);
            }
       }
    }

    //TTS 合成 + 播放
    static void tts_task(void *arg){
        char*text=(char*)arg;
        if(!text) return;
        //1. 追加助手回复到对话历史
        ai_conv_append("assistant",text);
        //2. TTS HTTP 合成
        char *path=NULL;
        err_t err=ai_tts_speak(text, &path);
        //调 ai_tts_speak——又是一个同步 HTTP 请求。把文本发给 TTS API（比如 OpenAI 的 /v1/audio/speech），返回一个 MP3 文件路径
        free(text);
        if(IS_OK(err)&&path){
            LOG_INFO("VA: TTS OK, starting playback: %s", path);
            /* A2DP ducking：TTS 播报时压低背景音乐音量 */
                err = audio_pipeline_play_tts(path);
            if(IS_ERR(err)){
                LOG_WARN("VA: audio_player_play_async failed");
                event_publish_simple(EV_AUDIO_ERROR);
            }
            free(path);
        }else{
            LOG_WARN("VA: TTS generation failed");
            event_publish_simple(EV_AUDIO_ERROR);
        }
    }


    /* ---- 单调时钟（ms），与 event_bus 内部一致 ---- */
    static int64_t now_ms(void){
        struct timespec ts;
        clock_gettime(CLOCK_MONOTONIC, &ts);
        return (int64_t)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
    }

    /* ---- 状态超时检测线程 ---- */
    static void *timeout_check_thread(void *arg) {
        (void)arg;
        while (s_va.inited) {
            int cur = sm_current_state();
            int64_t elapsed = now_ms() - s_va.state_entry_time;
            if (cur == ST_PROCESSING && elapsed > 30000)
                event_publish_simple(EV_AI_ERROR);
            else if (cur == ST_SPEAKING && elapsed > 60000)
                event_publish_simple(EV_AUDIO_ERROR);
            usleep(500000);  /* 500ms 检查一次 */
        }
        return NULL;
    }

    //状态机动作函数
    static void do_ai_request(int from,int to,int event,void *data){
        (void)from; (void)to; (void)event;(void)data;
        //from 转移前状态，to 转移后状态，event 触发事件
        if(!s_va.current_ev||!s_va.current_ev->data){
            LOG_ERROR("VA: do_ai_request with no data");
            event_publish_simple(EV_AI_ERROR);
            return;
        }
        const char*text=(const char*)s_va.current_ev->data;
        if(text[0]=='\0'){
            event_publish_simple(EV_AI_ERROR);
            return;
        }
        char *copy=strdup(text);
        if(!copy){
            event_publish_simple(EV_AI_ERROR);
            return;
        }
        task_id_t tid=thread_pool_submit(ai_request_task, copy,"ai_req");
        if(!tid){
            LOG_ERROR("VA: thread_pool_submit failed");
            free(copy);
            event_publish_simple(EV_AI_ERROR);
        }
    }


    //do_tts_and_play
    static void do_tts_and_play(int from, int to, int event,void *data)
    {
        (void) from;(void)to;(void)event;(void)data;
        if(!s_va.current_ev||!s_va.current_ev->data){
            LOG_ERROR("VA: do_tts_and_play with no data");
            event_publish_simple(EV_AUDIO_ERROR);
            return;
        }

        const char*text=(const char*)s_va.current_ev->data;

        if(text[0]=='\0'){
            event_publish_simple(EV_AUDIO_ERROR);
            return;
        }

        char *copy=strdup(text);
        if(!copy){
            event_publish_simple(EV_AUDIO_ERROR);
            return;
        }

        task_id_t tid=thread_pool_submit(tts_task, copy, "tts");
        if(!tid){
            LOG_ERROR("VA: thread_pool_submit failed");
            free(copy);
            event_publish_simple(EV_AUDIO_ERROR);
        }
    }

    /* EV_AUDIO_PLAY_DONE → 播放完成 */
    static void on_play_done(int from, int to, int event,void *data)
{
    (void)from; (void)to; (void)event;(void)data;
    LOG_INFO("VA: playback done");
    /* A2DP ducking 恢复：TTS 播完了，恢复背景音乐音量 */
}

/* EV_AUDIO_MUSIC_START → 音乐开始 */
static void on_music_start(int from, int to, int event,void *data)
{
    (void)from; (void)to; (void)event;(void)data;
    LOG_INFO("VA: music started");
}

/* EV_AUDIO_MUSIC_STOP → 音乐停止 */
static void on_music_stop(int from, int to, int event,void *data)
{
    (void)from; (void)to; (void)event;(void)data;
    LOG_INFO("VA: music stopped");
}

/* 各类错误 → 回 IDLE */
static void on_error(int from, int to, int event,void *data)
{
    (void)from; (void)to; (void)event;(void)data;
    LOG_WARN("VA: error, returning to IDLE (state %d)", from);
    /* A2DP ducking 恢复由 audio_pipeline 内部自动处理 */
}

/* EV_SYS_SHUTDOWN → 退出 */
static void on_shutdown(int from, int to, int event,void *data)
{
    (void)from; (void)to; (void)event;(void)data;
    LOG_INFO("VA: shutting down");
}


/* ==================================================================
 * 状态转移表
 * ================================================================ */
    //："当处于 X 状态时收到 Y 事件，就转到 Z 状态，顺便做 W 动作"
   static const sm_transition_t s_transitions[] = {
      /* 空闲 */
      { ST_IDLE,       EV_BT_DATA_RECEIVED,  ST_PROCESSING,  do_ai_request    },
      { ST_IDLE,       EV_AUDIO_MUSIC_START, ST_MUSIC,       on_music_start   },
      { ST_IDLE,       EV_BT_DEVICE_DISCONN, ST_IDLE,        NULL             },
      /* 音乐播放中 */
      { ST_MUSIC,      EV_AUDIO_MUSIC_STOP,  ST_IDLE,        on_music_stop    },
      { ST_MUSIC,      EV_BT_DATA_RECEIVED,  ST_PROCESSING,  do_ai_request    },
      /* AI 请求中 */
      { ST_PROCESSING, EV_AI_RESP_READY,     ST_SPEAKING,    do_tts_and_play  },
      { ST_PROCESSING, EV_AI_ERROR,          ST_IDLE,        on_error         },
      /* TTS 播报中 */
      { ST_SPEAKING,   EV_AUDIO_PLAY_DONE,   ST_IDLE,        on_play_done     },
      { ST_SPEAKING,   EV_AUDIO_ERROR,       ST_IDLE,        on_error         },
      /* 通配：任意状态 */
      { -1,            EV_SYS_SHUTDOWN,      ST_EXITING,     on_shutdown      },
      { -1,            EV_SYS_ERROR,         ST_IDLE,        on_error         },
  };

  /* ==================================================================
 * 事件处理入口
 * ================================================================ */

 static void on_event(const event_t *ev, void *user_data)
{
    (void)user_data;
    if(!ev) return;
    //保存事件引用，供 action 函数访问 ev->data
    s_va.current_ev=ev;
    err_t err=sm_dispatch((int)ev->id,ev->data);
    if(IS_OK(err)){
        s_va.state_entry_time=now_ms();
    }
    s_va.current_ev=NULL;
    //  核心三联：
  //1. 存 ev 到全局 → action 函数可以读 ev->data
  //2. 调 sm_dispatch → 查转移表 → 匹配就调 action + 切换状态
  //3. 清 current_ev → 防止 action 之外的代码误用

  if(IS_ERR(err)){
    //未找到匹配转移 — 在当前状态下忽略此事件
     LOG_DEBUG("VA: no transition for event 0x%04x in state %d",(unsigned)ev->id, sm_current_state());
  }
}


//模块生命周期
err_t voice_agent_init(void){
    if(s_va.inited) return ERR_OK;

    //读取AI客户端配置
    ai_client_config_t ai_cfg;
    memset(&ai_cfg,0,sizeof(ai_cfg));

    ai_cfg.api_url     = "https://api.deepseek.com/chat/completions";
    ai_cfg.api_key     = "";
    ai_cfg.model       = "deepseek-chat";
    ai_cfg.timeout_ms  = 30000;
    ai_cfg.temperature = 0.7f;
    ai_cfg.max_tokens  = 2048;
        
    if (g_config) {
        ai_cfg.api_url     = config_get_str(g_config, "ai", "api_url",     ai_cfg.api_url);
        ai_cfg.api_key     = config_get_str(g_config, "ai", "api_key",     ai_cfg.api_key);
        ai_cfg.model       = config_get_str(g_config, "ai", "model",       ai_cfg.model);
        ai_cfg.timeout_ms  = config_get_int(g_config,  "ai", "timeout",    ai_cfg.timeout_ms);
        ai_cfg.temperature = (float)config_get_int(g_config, "ai", "temperature", 70) / 100.0f;
        ai_cfg.max_tokens  = config_get_int(g_config,  "ai", "max_tokens", ai_cfg.max_tokens);
    }
        /* ---- 读取 TTS 配置 ---- */
    ai_tts_config_t tts_cfg;
    memset(&tts_cfg, 0, sizeof(tts_cfg));
    tts_cfg.api_url    = "https://api.openai.com/v1/audio/speech";
    tts_cfg.api_key    = "";
    tts_cfg.voice      = "alloy";
    tts_cfg.output_dir = "/tmp/speaker";

    if (g_config) {
        tts_cfg.api_url    = config_get_str(g_config, "tts", "api_url",    tts_cfg.api_url);
        tts_cfg.api_key    = config_get_str(g_config, "tts", "api_key",    tts_cfg.api_key);
        tts_cfg.voice      = config_get_str(g_config, "tts", "voice",      tts_cfg.voice);
        tts_cfg.output_dir = config_get_str(g_config, "tts", "output_dir", tts_cfg.output_dir);
    }
        /* ---- 读取音频配置 ---- */
    const char *audio_dev = "default";
    if (g_config) {
        audio_dev = config_get_str(g_config, "audio", "device", audio_dev);
    }
      /* ---- 读取系统提示词 ---- */
      const char *system_prompt =NULL;
      if(g_config){
        system_prompt=config_get_str(g_config, "ai", "system_prompt", NULL);
      }
      if(!system_prompt){
        system_prompt= "你是一个智能音箱助手。请用简洁、清晰的中文回答问题。"
                       "保持回答在100字以内，除非用户要求详细说明。";
      }
      //子模块初始化链
        //初始化子组建
   //  1. ai_client_init — 初始化 libcurl，设置 API URL/Key等
   //2. ai_tts_init — 初始化 TTS 客户端
   //3. ai_conv_init — 初始化对话管理器
    //为什么是这个顺序？ 因为 ai_conv 依赖 ai_client 和 ai_tts（它要调它们的函数），所以 ai_client 和 ai_tts 必须先初始化。如果 ai_conv 先初始化了但
    //ai_client 在 init 失败，ai_conv 的依赖就不完整。
  //错误回滚链：每一步失败时，要手动回滚前面已经成功的初始化。比如 ai_client 成功了但 ai_tts 失败：
  //ai_tts_init 失败 → ai_client_deinit() 回滚 → return err
      err_t err;
      err = ai_client_init(&ai_cfg);
      if (IS_ERR(err)) return err;

      err = ai_tts_init(&tts_cfg);
      if (IS_ERR(err)) { ai_client_deinit(); return err; }

      err = ai_conv_init(system_prompt);
      if (IS_ERR(err)) { ai_tts_deinit(); ai_client_deinit(); return err; }

    /* ---- 初始化音频管道（内部管理播放器、A2DP、混音、录音） ---- */
    {
        audio_pipeline_config_t ap_cfg;
        memset(&ap_cfg, 0, sizeof(ap_cfg));
        ap_cfg.playback_device      = audio_dev;
        ap_cfg.capture_device       = audio_dev;
        ap_cfg.capture_rate         = 16000;
        ap_cfg.a2dp_device          = audio_dev;
        ap_cfg.a2dp_ringbuf_frames  = 256;
        err = audio_pipeline_init(&ap_cfg);
        if (IS_ERR(err)) {
            LOG_WARN("VA: audio pipeline init failed");
        }
    }

    /* 创建 TTS 输出目录 */
    char mkdir_cmd[256];
    snprintf(mkdir_cmd, sizeof(mkdir_cmd),
             "mkdir -p %s 2>/dev/null", tts_cfg.output_dir);
    system(mkdir_cmd);

    //初始化状态机 
    sm_init(s_transitions, ARRAY_SIZE(s_transitions), ST_IDLE);
        /* ---- 订阅事件 ---- */
    s_va.sub_bt_data   = event_subscribe(EV_BT_DATA_RECEIVED,  on_event, NULL);
    s_va.sub_ai_ready  = event_subscribe(EV_AI_RESP_READY,     on_event, NULL);
    s_va.sub_ai_error  = event_subscribe(EV_AI_ERROR,          on_event, NULL);
    s_va.sub_play_done = event_subscribe(EV_AUDIO_PLAY_DONE,   on_event, NULL);
    s_va.sub_audio_error = event_subscribe(EV_AUDIO_ERROR,     on_event, NULL);
    s_va.sub_music_start = event_subscribe(EV_AUDIO_MUSIC_START, on_event, NULL);
    s_va.sub_music_stop  = event_subscribe(EV_AUDIO_MUSIC_STOP,  on_event, NULL);
    s_va.sub_shutdown  = event_subscribe(EV_SYS_SHUTDOWN,      on_event, NULL);
    s_va.sub_disconn   = event_subscribe(EV_BT_DEVICE_DISCONN, on_event, NULL);

    if (!s_va.sub_bt_data || !s_va.sub_ai_ready || !s_va.sub_shutdown) {
        LOG_ERROR("VA: event subscribe failed");
        voice_agent_deinit();
        return ERR_NOMEM;
    }
    s_va.state_entry_time = now_ms();
    if (pthread_create(&s_va.timeout_thread, NULL, timeout_check_thread, NULL) != 0) {
        LOG_ERROR("VA: failed to create timeout thread");
        voice_agent_deinit();
        return ERR_GENERAL;
    }

    s_va.inited = true;
    LOG_INFO("Voice agent initialized (model=%s, tts_voice=%s)",
             ai_cfg.model, tts_cfg.voice);
    return ERR_OK;
}

void voice_agent_shutdown(void)
{
    LOG_INFO("VA: shutdown requested");
}
//反初始化
void voice_agent_deinit(void){
    if (!s_va.inited) return;

    /* 先停超时检测线程（signal→join，避免线程在卸载期间发布事件） */
    s_va.inited = false;
    pthread_join(s_va.timeout_thread, NULL);

    event_unsubscribe(s_va.sub_bt_data);
    event_unsubscribe(s_va.sub_ai_ready);
    event_unsubscribe(s_va.sub_ai_error);
    event_unsubscribe(s_va.sub_play_done);
    event_unsubscribe(s_va.sub_audio_error);
    event_unsubscribe(s_va.sub_music_start);
    event_unsubscribe(s_va.sub_music_stop);
    event_unsubscribe(s_va.sub_shutdown);
    event_unsubscribe(s_va.sub_disconn);

    ai_conv_deinit();
    ai_tts_deinit();
    ai_client_deinit();
    audio_pipeline_deinit();

    LOG_INFO("VA: deinitialized");
}

MODULE_DEFINE(voice_agent, voice_agent_init, voice_agent_deinit,
    voice_agent_shutdown, MODULE_PRIO_APPLICATION);