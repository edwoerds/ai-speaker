  #include "ai_client.h"
  #include "logger.h"
  #include <curl/curl.h>
  #include <stdio.h>
  #include <stdlib.h>
  #include <string.h>
  #include <unistd.h>


    /*
   * TTS 客户端 — 调用 OpenAI 兼容 TTS API
   *
   * POST /v1/audio/speech
   * {
   *   "model": "tts-1",
   *   "input": "要合成的文本",
   *   "voice": "alloy"
   * }
   * → 返回 MP3 音频二进制
   */



  /* ==================================================================
   * 全局状态
   * ================================================================ */
  static struct {
      ai_tts_config_t cfg;// cfg — 保存配置（api_url, api_key, voice, output_dir）
      bool inited;
  } s_tts = {0};
//当前序号（防止文件名冲突）
  static int s_seq = 0;

    /* ==================================================================
   * libcurl write 回调：写入文件
   * ================================================================ */

   struct file_ctx {
      FILE *fp;        /* 打开的文件指针 */
      char *path;      /* 文件路径（调用方 free） */
      int   ok;        /* 写入是否成功的标志 */
  };

// libcurl 的写回调。libcurl 每收到一段数据就调一次这个函数
   static size_t write_file_cb(char *data, size_t size, size_t nmemb, void *userp)
  {
      struct file_ctx *fc = (struct file_ctx *)userp;
      if (!fc->fp) return 0;
      size_t written = fwrite(data, size, nmemb, fc->fp);
      if (written < nmemb) fc->ok = 0;//：如果实际写入的块数少于应该写入的，标记 ok = 0（磁盘满了或其他错误）
      return written;
  }
  

  /* ==================================================================
 * 接口实现
 * ================================================================ */

 err_t ai_tts_init(const ai_tts_config_t *cfg){
    if (!cfg) return ERR_INVAL;
    s_tts.cfg = *cfg;
          /* 默认值 */
      if (!s_tts.cfg.api_url)    s_tts.cfg.api_url    = "https://api.openai.com/v1/audio/speech";
      if (!s_tts.cfg.voice)      s_tts.cfg.voice      = "alloy";
      if (!s_tts.cfg.output_dir) s_tts.cfg.output_dir = "/tmp/speaker";
      s_tts.inited = true;
      LOG_INFO("TTS initialized (voice=%s)", s_tts.cfg.voice);
      return ERR_OK;
 }

   void ai_tts_deinit(void)
  {
      s_tts.inited = false;
      LOG_INFO("TTS deinitialized");
  }

  //参数校验+路径构建
  err_t ai_tts_speak(const char *text,char **out_path){
    if(!s_tts.inited||!text||!out_path) 
        return ERR_INVAL;//// 三合一参数检查
    if(text[0]=='\0')
        return ERR_INVAL;//空字符串拒绝掉
    char path[512];
    int seq=__sync_fetch_and_add(&s_seq,1);//原子自增
    snprintf(path, sizeof(path), "%s/tts_%06d.mp3",
               s_tts.cfg.output_dir ? s_tts.cfg.output_dir : "/tmp/speaker", seq);
    // GCC 内置的原子操作，等价于 seq = s_seq++; 但是线程安全
  // 两个线程同时调 ai_tts_speak，不会拿到同一个序号
  // 文件名格式：tts_000000.mp3, tts_000001.mp3...


  //打开输出文件
  FILE*fp=fopen(path,"wb");
  if(!fp){
    LOG_ERROR("TTS: cannot open output file: %s", path);
     return ERR_NODEV;     // "设备不存在" → 实际是"文件打不开"
  }

  //构建 JSON payload 
  char *json_buf=NULL;
  size_t json_len=0;
  FILE *json_stream=open_memstream(&json_buf, &json_len);
  if(!json_stream){
    fclose(fp);
    unlink(path);//回滚：删掉半成品文件
    return ERR_NOMEM;
  }
  
  // JSON 转义 text 中的 " 和反斜杠
  fprintf(json_stream,"{\n");
  fprintf(json_stream,"\"model\":\"tts-1\",\n");
  fprintf(json_stream,"\"input\":\"");
  const char *src=text;
  while(*src){
     if (*src == '"' || *src == '\\') fputc('\\', json_stream);    // 转义引号、反斜杠
     if (*src == '\n') { fputc('\\', json_stream); fputc('n', json_stream); }    // 换行→\n
     else if (*src == '\t') { fputc('\\', json_stream); fputc('t', json_stream); } // 制表符→\t
     else fputc(*src, json_stream);
     src++;
  }
  fprintf(json_stream, "\",\n");
  fprintf(json_stream, "  \"voice\": \"%s\"\n", s_tts.cfg.voice ? s_tts.cfg.voice : "alloy");
  fprintf(json_stream, "}\n");
  fclose(json_stream);          // 关闭内存流，json_buf 和 json_len 最终确定

  if (!json_buf) {    // open_memstream 失败的极端情况
  fclose(fp);
  unlink(path);
  return ERR_NOMEM;
  }

  //准备 CURL 请求
  CURL *curl =curl_easy_init();
  if(!curl){
    free(json_buf);
    fclose(fp);
    unlink(path);
    return ERR_NOMEM;
  }

  struct curl_slist *headers=NULL;
  headers=curl_slist_append(headers,"Content-Type: application/json");
  if(s_tts.cfg.api_key&&s_tts.cfg.api_key[0])
  {
    char auth[512];
    snprintf(auth, sizeof(auth), "Authorization: Bearer %s", s_tts.cfg.api_key);
    headers = curl_slist_append(headers, auth);
  }

  struct file_ctx fctx;
  fctx.fp =fp;
  fctx.path=strdup(path);
  fctx.ok=1;

  curl_easy_setopt(curl, CURLOPT_URL,            s_tts.cfg.api_url);
  curl_easy_setopt(curl, CURLOPT_HTTPHEADER,     headers);
  curl_easy_setopt(curl, CURLOPT_POSTFIELDS,     json_buf);// POST body
  curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE,  (long)json_len); // body 长度
  curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION,  write_file_cb);// 数据回调
  curl_easy_setopt(curl, CURLOPT_WRITEDATA,      &fctx);// 回调参数
  curl_easy_setopt(curl, CURLOPT_TIMEOUT_MS,     60000L);// 60s 超时
  curl_easy_setopt(curl, CURLOPT_USERAGENT,      "AI-Speaker/1.0");// 标识客户端
  curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L); // 跳过证书验证
  curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);

  //执行请求 + 错误处理
  CURLcode rc = curl_easy_perform(curl);

  fclose(fp);
  if(rc!=CURLE_OK){
    LOG_ERROR("TTS request failed: %s", curl_easy_strerror(rc));
    unlink(path);
    free(fctx.path);
    free(json_buf);
    curl_easy_cleanup(curl);
    curl_slist_free_all(headers);
    return ERR_GENERAL;
  }
  //网络错误回滚：删文件、释放所有资源

  long http_code=0;
  curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &http_code);
  if(http_code!=200){//HTTP 状态码要单独检查——400 表示"请求参数错误"，500 表示"服务器炸了"即使是 404，curl_easy_perform 也返回 CURLE_OK！
    LOG_ERROR("TTS API returned HTTP %ld", http_code);
    unlink(path);
    free(fctx.path);
    free(json_buf);
    curl_easy_cleanup(curl);
    curl_slist_free_all(headers);
    return ERR_GENERAL;
  }

  // 成功：返回文件路径
  LOG_INFO("TTS audio saved: %s (%d bytes)", path, (int)json_len);
  *out_path = fctx.path;
  free(json_buf);
  curl_easy_cleanup(curl);
  curl_slist_free_all(headers);
  return ERR_OK;
  }

  